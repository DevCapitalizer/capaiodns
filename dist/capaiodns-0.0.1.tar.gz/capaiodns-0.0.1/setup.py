from setuptools import find_packages, setup


setup(
    name="capaiodns",
    version="0.0.1",
    description="None",
    packages=['capaiodns'],
    long_description='Long long',
    long_description_content_type="text/markdown",
    url="https://github.com/DevCapitalizer/capaiodns",
    author="DDjango",
    author_email="ddjango.786@gmail.com",
    license="MIT",
    # classifiers=[
    #     "License :: OSI Approved :: MIT License",
    #     "Programming Language :: Python :: 3.9",
    #     "Operating System :: OS Independent",
    # ],
    python_requires=">=3.9",
)